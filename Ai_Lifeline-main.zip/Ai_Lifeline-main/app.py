from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/resources")
def resources():
    return render_template("resources.html")

@app.route("/chatbot")
def chatbot():
    return render_template("chatbot.html")

# Dummy chatbot API for testing
@app.route("/ask", methods=["POST"])
def ask():
    user_message = request.json.get("message")
    reply = f"🤖 Lifeline AI: You asked '{user_message}'. Nearby shelters and hospitals will be shown soon!"
    return jsonify({"reply": reply})

if __name__ == "__main__":
    app.run(debug=True)
